#ifndef LZFU_H
#define LZFU_H
unsigned char* lzfu_decompress (unsigned char* rtfcomp);
#endif
