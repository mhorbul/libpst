#!/bin/sh -e

echo Running aclocal
aclocal
echo Running autoheader
autoheader
echo Running autoconf
autoconf
echo Running automake
automake
